
function show (){
	var str = "123"; //保存生成信息
	var str2 = "\n青岛惠城环保科技股份有限公司\n";	//保存公司名称
	var str3 = ""; 	//保存发送日期


	var phoneNum = "";	//获取发送号码
	var f= form;
	phoneNum = f.phoneNum.value;

	var year = "";	//获取年份
	var id = document.getElementById("year");
	var index = id.selectedIndex;
	year = id.options[index].text;

	var month ="";//获取月份
	var id_m = document.getElementById("month");
	index = id_m.selectedIndex;
	month = id_m.options[index].text;

	var day =""; //获取日
	var id_d = document.getElementById("day");
	index = id_d.selectedIndex;
	day = id_d.options[index].text;

	var good ="";	//获取货物种类
	var id_g = document.getElementById("good");
	index = id_g.selectedIndex;
	good = id_g.options[index].value;

	var weight = "";	//获取货物重量
	var f= form;
	weight = f.weight.value;

	var year01 = "";	//获取年份01
	var id01 = document.getElementById("year01");
	index = id01.selectedIndex;
	year01 = id01.options[index].text;

	var month01 ="";	//获取月份01
	var id_m01 = document.getElementById("month01");
	index = id_m01.selectedIndex;
	month01 = id_m01.options[index].text;

	var day01 ="";	//获取日01
	var id_d01 = document.getElementById("day01");
	index = id_d01.selectedIndex;
	day01 = id_d01.options[index].text;

	var car = "";	//获取车牌号
	car = f.car.value;

	var phone = "";	//获取手机号
	phone = f.phone.value;

	var province =""; //获取省份
	var id_province = document.getElementById("province");
	index = id_province.selectedIndex;
	province = id_province.options[index].value;

	var city ="";	//获取城市名
	var id_city = document.getElementById("city");
	index = id_city.selectedIndex;
	city = id_city.options[index].value;

	var district ="";	//获取区域名
	var id_district = document.getElementById("district");
	index = id_district.selectedIndex;
	district = id_district.options[index].value;
		
/*
	var year02 = "";	//获取年份02
	var id02 = document.getElementById("year02");
	index = id02.selectedIndex;
	year02 = id02.options[index].text;

	var month02 ="";	//获取月份02
	var id_m02 = document.getElementById("month02");
	index = id_m02.selectedIndex;
	month02 = id_m02.options[index].text;

	var day02 ="";	//获取日02
	var id_d02 = document.getElementById("day02");
	index = id_d02.selectedIndex;
	day02 = id_d02.options[index].text;

	str3 = year02+month02+day02; //发送短信日期
	*/

	//获取当前时间
	var nowData = new Date();
	var time;	
	var mon = nowData.getMonth() + 1; 
	time = nowData.getFullYear()+"-"+mon+"-"+nowData.getDate()+"  "+nowData.getHours()+" : "+nowData.getMinutes()+" : "+nowData.getSeconds();
	
	//预览信息
	str = phoneNum + ":\n" + "我公司于"+year+month+day+"，发货"+good+","+weight+"吨，计划"+year01+month01+day01+"到厂，车辆信息："+car+"，司机："+phone+"，送货地点: "+province+city+district+"。";
	str += str2+time; //完整信息
	
	//更新当前发送时间
	document.getElementById("time").innerHTML = '<p value="'+time+'">发送时间: '+time+'</p>';
	alert(str);
	
}


function show2(){

	var phoneNum = "";	//获取发送号码
	var f= form2;
	phoneNum = f.phoneNum2.value;
	
	
	var custom1 = "";	//获取客户名
	custom1 = f.custom1.value;

	var contain = "";	//获取装置
	contain = f.contain.value;

	var content = "";	//获取包含内容
	content = f.content.value;

	var custom2 = "";	//获取客户名
	custom2 = f.custom2.value;

	var name = "";		//获取姓名
	name = f.name.value;

	var phoneNum02_1 = "";		//获取手机号
	phoneNum02_1 = f.phoneNum02_1.value;



	//获取当前时间
	var nowData = new Date();
	var time;	
	var mon = nowData.getMonth() + 1; 
	time = nowData.getFullYear()+"-"+mon+"-"+nowData.getDate()+"  "+nowData.getHours()+" : "+nowData.getMinutes()+" : "+nowData.getSeconds();
	
	//预览信息生成
	var str =  "尊敬的"+custom1+"客户您好，我公司催化裂化技术服务中心已完成"+contain+"装置各样品的理化性能检测，包括："+content+"，样品分析报告单已发送至您邮箱，请您查收。"+custom2+"技术服务专员"+name+"，联系方式："+phoneNum02_1+"。 青岛惠城环保科技股份有限公司 ";
	
	str += time; //完整信息
	if(content.length>20)
	{
		alert("包括后的输入超过20字，请减少输入!")
	}
	else
	{
		//更新当前发送时间
		document.getElementById("time").innerHTML = '<p value="'+time+'">发送时间: '+time+'</p>';
		alert(str);
	}
	
}
	


function show3(){

	var phoneNum = "";	//获取发送号码
	var f= form3;
	phoneNum = f.phoneNum3.value;
	
	
	var custom3 = "";	//获取客户名
	custom3 = f.custom3.value;

	var custom4 = "";	//获取客户名
	custom4 = f.custom4.value;

	var year3 = "";
	year3 = f.year3.value;

	var month3 = "";
	month3 = f.month3.value;

	var day3 = "";
	day3 = f.day3.value;


	var report = "";		//获取报告名
	report = f.report.value;

	var custom5 = "";		//获取客户
	custom5 = f.custom5.value;

	var name = "";		//获取客户
	name = f.name2.value;

	var phoneNum3_1 = "";		//获取手机号
	phoneNum3_1 = f.phoneNum3_1.value;

	//获取当前时间
	var nowData = new Date();
	var time;	
	var mon = nowData.getMonth() + 1; 
	time = nowData.getFullYear()+"-"+mon+"-"+nowData.getDate()+"  "+nowData.getHours()+" : "+nowData.getMinutes()+" : "+nowData.getSeconds();
	
	//预览信息生成
	var str =  "尊敬的"+custom3+"客户您好，我公司催化裂化技术服务中心针对"+custom4+"近期催化装置生产情况，于"+year3+"年"+month3+"月"+day3+"日召开了专题用剂分析会，形成了"+report+"，相关资料已发送至您邮箱，请您查收。"+custom5+"技术服务专员"+name+"，联系方式："+phoneNum3_1+"。 青岛惠城环保科技股份有限公司 ";
	
	str += time; //完整信息
	
	//更新当前发送时间
	document.getElementById("time").innerHTML = '<p value="'+time+'">发送时间: '+time+'</p>';
	alert(str);
}	