function isPoneAvailable(str) {
            var myreg=/^[1][3,4,5,7,8][0-9]{9}$/;
            if (!myreg.test(str)) {
                return false;
            } else {
                return true;
            }
        }


function sendto()
{ 
    var phoneNum = "";	//获取发送号码
	var f= form;
	phoneNum = f.phoneNum.value;
	
    var str = ""; //保存生成信息
	var str2 = "\n青岛惠城环保科技股份有限公司\n";	//保存公司名称
	var str3 = ""; 	//保存发送日期

	var year = "";	//获取年份
	var id = document.getElementById("year");
	var index = id.selectedIndex;
	year = id.options[index].text;

	var month ="";//获取月份
	var id_m = document.getElementById("month");
	index = id_m.selectedIndex;
	month = id_m.options[index].text;

	var day =""; //获取日
	var id_d = document.getElementById("day");
	index = id_d.selectedIndex;
	day = id_d.options[index].text;

	var good ="";	//获取货物种类
	var id_g = document.getElementById("good");
	index = id_g.selectedIndex;
	good = id_g.options[index].value;

	var weight = "";	//获取货物重量
	var f= form;
	weight = f.weight.value;

	var year01 = "";	//获取年份01
	var id01 = document.getElementById("year01");
	index = id01.selectedIndex;
	year01 = id01.options[index].text;

	var month01 ="";	//获取月份01
	var id_m01 = document.getElementById("month01");
	index = id_m01.selectedIndex;
	month01 = id_m01.options[index].text;

	var day01 ="";	//获取日01
	var id_d01 = document.getElementById("day01");
	index = id_d01.selectedIndex;
	day01 = id_d01.options[index].text;

	var car = "";	//获取车牌号
	car = f.car.value;

	var phone_car = "";	//获取司机手机号
	phone_car = f.phone.value;

	var province =""; //获取省份
	var id_province = document.getElementById("province");
	index = id_province.selectedIndex;
	province = id_province.options[index].value;

	var city ="";	//获取城市名
	var id_city = document.getElementById("city");
	index = id_city.selectedIndex;
	city = id_city.options[index].value;
    
    var district ="";	//获取区域名
	var id_district = document.getElementById("district");
	index = id_district.selectedIndex;
	district = id_district.options[index].value;
	
	//获取当前时间
	var nowData = new Date();
	var time;	
	var mon = nowData.getMonth() + 1; 
	time = nowData.getFullYear()+"-"+mon+"-"+nowData.getDate()+"  "+nowData.getHours()+" : "+nowData.getMinutes()+" : "+nowData.getSeconds();
	

   	if(!isPoneAvailable(phoneNum))
  	 	alert("请输入正确的手机号");
	else if(isPoneAvailable(phoneNum)&&weight!=""&&car!=""&&phone_car!=""&&province!=""&&city!=""&&district!="")
	{
		 //更新当前发送时间
		document.getElementById("time").innerHTML = '<p value="'+time+'">发送时间: '+time+'</p>';
		alert("模板一短信已发送");
	}
     	
	 else
		 alert("请将模板一信息填写完整");
}
function sendto2()
{ 
    var phoneNum = "";	//获取发送号码
	var f= form2;
	phoneNum = f.phoneNum2.value;
	
	
	var custom1 = "";	//获取客户名
	custom1 = f.custom1.value;

	var contain = "";	//获取装置
	contain = f.contain.value;

	var content = "";	//获取包含内容
	content = f.content.value;

	var custom2 = "";	//获取客户名
	custom2 = f.custom2.value;

	var name = "";		//获取姓名
	name = f.name.value;

	var phoneNum02_1 = "";		//获取手机号
	phoneNum02_1 = f.phoneNum02_1.value;


	//获取当前时间
	var nowData = new Date();
	var time;	
	var mon = nowData.getMonth() + 1; 
	time = nowData.getFullYear()+"-"+mon+"-"+nowData.getDate()+"  "+nowData.getHours()+" : "+nowData.getMinutes()+" : "+nowData.getSeconds();
	
	if(content.length>20)
	{
		alert("包括后的输入超过20字，请减少输入!")
	}
	else if(!isPoneAvailable(phoneNum) && !isPoneAvailable(phoneNum02_1) )
  	 	alert("请输入正确的手机号");
	else if(custom1!="" && contain!="" && contain!="" && content!="" && custom2!="" && name!="")
	{
		document.getElementById("time").innerHTML = '<p value="'+time+'">发送时间: '+time+'</p>';
		alert("模板二短信已发送");
	}
	else
	{
		alert("请将模板二信息填写完整");
	}
}
function sendto3()
{ 
    var phoneNum = "";	//获取发送号码
	var f= form3;
	phoneNum = f.phoneNum3.value;
	
	
	var custom3 = "";	//获取客户名
	custom3 = f.custom3.value;

	var custom4 = "";	//获取客户名
	custom4 = f.custom4.value;

	var year3 = "";
	year3 = f.year3.value;

	var month3 = "";
	month3 = f.month3.value;

	var day3 = "";
	day3 = f.day3.value;


	var report = "";		//获取报告名
	report = f.report.value;

	var custom5 = "";		//获取客户
	custom5 = f.custom5.value;

	var name = "";		//获取客户
	name = f.name2.value;

	var phoneNum3_1 = "";		//获取手机号
	phoneNum3_1 = f.phoneNum3_1.value;


	//获取当前时间
	var nowData = new Date();
	var time;	
	var mon = nowData.getMonth() + 1; 
	time = nowData.getFullYear()+"-"+mon+"-"+nowData.getDate()+"  "+nowData.getHours()+" : "+nowData.getMinutes()+" : "+nowData.getSeconds();
	

	if(!isPoneAvailable(phoneNum) && !isPoneAvailable(phoneNum3_1) )
  	 	alert("请输入正确的手机号");
	else if(custom3!="" && report!="" && year3!="" && month3!="" && day3!="" && custom5!="" && custom4!="" && name!="")
	{
		document.getElementById("time").innerHTML = '<p value="'+time+'">发送时间: '+time+'</p>';
		alert("模板三短信已发送");
	}
	else
	{
		alert("请将模板三信息填写完整");
	}
}