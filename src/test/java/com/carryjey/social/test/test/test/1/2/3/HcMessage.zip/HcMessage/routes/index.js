var express = require('express');
var router = express.Router();
var mongodb = require('mongodb');
var mongoose = require('mongoose');
var MongoClient = mongodb.MongoClient;
var DB_CONN_STR = 'mongodb://localhost:27017/hcMessage';
var text = require('../public/module/text');

var Text = text.Text;
var login_name = "", user_name = "huichengxs2017";
var login_pass = "", user_password = "huicheng001";

const Core = require('@alicloud/pop-core');

const accessKeyId = 'LTAI4FmQBSX3AXS8cZhrXugX'
const secretAccessKey = 'TNRe3J7AiCx1bvnFWQ0RSy1pnAhGKh'


//初始化sms_client
var client = new Core({
    accessKeyId: accessKeyId,
    accessKeySecret: secretAccessKey,
    endpoint: 'https://dysmsapi.aliyuncs.com',
    apiVersion: '2017-05-25'
});


//判断是否为手机号
function isPoneAvailable(str) {
    var myreg = /^[1][3,4,5,7,8][0-9]{9}$/;
    if (!myreg.test(str)) {
        return false;
    } else {
        return true;
    }
}

//判断是否为日期
function isData(str) {
    var myreg = /(([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29)/;
    if (!myreg.test(str)) {
        return false;
    } else {
        return true;
    }
}

/* GET home page. */
router.get('/', function (req, res, next) {
    login_name = "";
    login_pass = "";
    res.render('login', {title: '惠城科技登录'});
});
/* GET index page. */
router.get('/index', function (req, res, next) {
    if (login_name == user_name && login_pass == user_password) {
        res.render('index', {title: '惠城科技登录'});
    } else {
        res.render('login', {title: '惠城科技登录'});
    }
});

router.post('/', function (req, res, next) {
    if (req.body.username == user_name && req.body.password == user_password) {
        login_name = req.body.username;
        login_pass = req.body.password;
        res.render('index', {title: '惠城科技', phoneNum: ''});
    } else {
        res.redirect('/');
    }
});


//将短信存入数据库，分别存发送手机号，发送时间（2017-1-1），货物类型，短信内容
router.post('/index', function (req, res, next) {
    //获取当前时间
    var nowData = new Date();
    var time;
    var mon = nowData.getMonth() + 1;

    time = nowData.getFullYear() + "-" + mon + "-" + nowData.getDate();
    time01 = nowData.getFullYear() + "-" + mon + "-" + nowData.getDate() + "  " + nowData.getHours() + " : " + nowData.getMinutes() + " : " + nowData.getSeconds();
    var send_time = time;
    var phoneNum = req.body.phoneNum;
    var phoneNum2 = req.body.phoneNum2;
    var phoneNum3 = req.body.phoneNum3;
    if (isPoneAvailable(phoneNum) && !isPoneAvailable(phoneNum2) && !isPoneAvailable(phoneNum3)) {
        var message = "我公司于" + req.body.year + "年" + req.body.month + "月" + req.body.day + "日，发货" + req.body.good + "," + req.body.weight + "吨，计划" + req.body.year01 + "年" + req.body.month01 + "月" + req.body.day01 + "日到厂，车辆信息：" + req.body.car + "，司机手机号：" + req.body.phone + "，送货地点:" + req.body.province + req.body.city + req.body.district + " 。" + "青岛惠城环保科技股份有限公司 " + time01;
        var good_type = req.body.good;
        console.log(message, send_time, good_type);
        var T = new Text({
            phoneNum: phoneNum,
            send_time: time,
            good_type: good_type,
            message: message,
        });
        if (login_name == user_name && login_pass == user_password && isPoneAvailable(phoneNum) && req.body.car != "" && req.body.weight != "" && req.body.phone != "" && req.body.province != "" && req.body.city != "" && req.body.district != "") {
            //保存到数据库
            T.save(function (err, doc) {
                if (err)
                    console.log(err);
                else
                    console.log("save successful");
            });

            //获取json数组
            var message_json = [
                {
                    "year": req.body.year,
                    "month": req.body.month,
                    "day": req.body.day,
                    "good": req.body.good,
                    "weight": req.body.weight,
                    "year01": req.body.year01,
                    "month01": req.body.month01,
                    "day01": req.body.day01,
                    "car": req.body.car,
                    "phone": req.body.phone,
                    "district": req.body.province + req.body.city + req.body.district
                }
            ];

            //发送短信
            var params = {
                "RegionId": "cn-hangzhou",
                "PhoneNumbers": phoneNum,
                "SignName": "惠城环保科技",
                "TemplateCode": "SMS_175121543",
                "TemplateParam": JSON.stringify(message_json[0])
            }

            var requestOption = {
                method: 'POST'
            };

            client.request('SendSms', params, requestOption).then((result) => {
                console.log(JSON.stringify(result));
            }, (ex) => {
                console.log(ex);
            })

        }//if
        else {
            res.render('index', {title: '惠城科技', phoneNum: ''});
        }//else
    }//if(phone:1)
    else if (!isPoneAvailable(phoneNum) && isPoneAvailable(phoneNum2) && !isPoneAvailable(phoneNum3)) {
        var phoneNum2_1 = req.body.phoneNum02_1;
        var send_time = time;
        var good_type = "";
        var message = "尊敬的" + req.body.recustom1 + "客户您好，我公司催化裂化技术服务中心已完成" + req.body.contain + "装置各样品的理化性能检测，包括：" + req.body.content + "，样品分析报告单已发送至您邮箱，请您查收。" + req.body.custom2 + "技术服务专员" + req.body.name + "，联系方式：" + req.body.phoneNum02_1 + "。 青岛惠城环保科技股份有限公司 " + time01;
        var T = new Text({
            phoneNum: phoneNum2,
            send_time: time,
            good_type: good_type,
            message: message,
        });
        console.log(message);
        //保存到数据库
        var content = req.body.content;
        if (login_name == user_name && login_pass == user_password && isPoneAvailable(phoneNum2) && content.length < 20) {
            T.save(function (err, doc) {
                if (err)
                    console.log(err);
                else
                    console.log("save successful");
            });
            var message_json1 = [
                {
                    "custom": req.body.custom1,
                    "contain": req.body.contain,
                    "content": req.body.content,
                    "custom2": req.body.custom2,
                    "name": req.body.name,
                    "phoneNum02": req.body.phoneNum02_1
                }
            ];

            //发送短信
            var params = {
                "RegionId": "cn-hangzhou",
                "PhoneNumbers": phoneNum2,
                "SignName": "惠城环保科技",
                "TemplateCode": "SMS_175121661",
                "TemplateParam": JSON.stringify(message_json1[0])
            }

            var requestOption = {
                method: 'POST'
            };

            client.request('SendSms', params, requestOption).then((result) => {
                console.log(JSON.stringify(result));
            }, (ex) => {
                console.log(ex);
            })
        } else {
            res.render('index', {title: '惠城科技', phoneNum2: ''});
        }//else
    }//else if(phone2:1)
    else if (!isPoneAvailable(phoneNum) && !isPoneAvailable(phoneNum2) && isPoneAvailable(phoneNum3)) {
        var phoneNum3_1 = req.body.phoneNum3_1;
        var send_time = time;
        var good_type = "";
        var message = "尊敬的" + req.body.custom3 + "客户您好，我公司催化裂化技术服务中心针对" + req.body.custom4 + "近期催化装置生产情况，于" + req.body.year3 + "年" + req.body.month3 + "月" + req.body.day3 + "日召开了专题用剂分析会，形成了" + req.body.report + "，相关资料已发送至您邮箱，请您查收。" + req.body.custom5 + "技术服务专员" + req.body.name + "，联系方式：" + req.body.phoneNum3_1 + "。 青岛惠城环保科技股份有限公司 ";
        var T = new Text({
            phoneNum: phoneNum3,
            send_time: time,
            good_type: good_type,
            message: message,
        });
        console.log(message);
        //保存到数据库
        if (login_name == user_name && login_pass == user_password && isPoneAvailable(phoneNum3)) {
            T.save(function (err, doc) {
                if (err)
                    console.log(err);
                else
                    console.log("save successful");
            });
            var message_json2 = [
                {
                    "custom": req.body.custom3,
                    "custom2": req.body.custom4,
                    "year": req.body.year3,
                    "month": req.body.month3,
                    "day": req.body.day3,
                    "report": req.body.report,
                    "custom3": req.body.custom5,
                    "name": req.body.name2,
                    "phoneNum": req.body.phoneNum3_1
                }
            ];

            //发送短信
            var params = {
                "RegionId": "cn-hangzhou",
                "PhoneNumbers": phoneNum3,
                "SignName": "惠城环保科技",
                "TemplateCode": "SMS_175175266",
                "TemplateParam": JSON.stringify(message_json2[0])
            }

            var requestOption = {
                method: 'POST'
            };

            client.request('SendSms', params, requestOption).then((result) => {
                console.log(JSON.stringify(result));
            }, (ex) => {
                console.log(ex);
            })
        } else {
            res.render('index', {title: '惠城科技', phoneNum2: ''});
        }//else
    }


    res.redirect('/index');
}); //app.post("/index")


router.post('/findall', function (req, res, next) {
    Text.find(function (err, doc) {
        if (err)
            console.log(err);
        else
            res.json(doc);
    })
})

//查询数据库
router.post('/find', function (req, res, next) {
    var mes = {"message": 1, "phoneNum": 1, "_id": 0};
    var time_find = {"send_time": req.body.find};
    var phoneNum_find = {"phoneNum": req.body.find};
    var good_find = {"good_type": req.body.find};

    if (isPoneAvailable(req.body.find)) {
        Text.find(phoneNum_find, mes, function (err, doc) {
            if (err)
                console.log(err);
            else
                res.json(doc);
        })
    } //if
    else if (isData(req.body.find)) {
        Text.find(time_find, mes, function (err, doc) {
            if (err)
                console.log(err);
            else
                res.json(doc);
        })
    } else {
        Text.find(good_find, mes, function (err, doc) {
            if (err)
                console.log(err);
            else
                res.json(doc);
        })
    }
});//查询


module.exports = router;